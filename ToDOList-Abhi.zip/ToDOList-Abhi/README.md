# to-do-list.github.io
To-do list website

Hello, #connections!

I'm glad to share that I have completed Task-1 of my internship as a Web Development Intern with Code Clause Internship Program. This beginner-friendly tutorial is perfect for aspiring web developers who want to enhance their knowledge of HTML, CSS, JavaScript, and Bootstrap.

For this task, I developed a To-Do List using Visual Studio Code. I would appreciate it if you could take a look at my work and leave your valuable suggestions for improvement.

Thank you, Code Clause, for providing me with this opportunity to learn and grow.

By Abhishek Mishra
